<?php

    /*
     * La iteración sólo funciona con propiedades públicas, excluyendo propiedades 
     * privadas o protegidas
     */

    class Usuario {

        public $nombre = 'Juan';
        private $edad = 34;
        protected $salario = 4200.00;

    }

    $usuario = new Usuario();

    foreach ($usuario as $k => $v) {
        echo "clave: $k, valor: $v" . "<br>";
    }
