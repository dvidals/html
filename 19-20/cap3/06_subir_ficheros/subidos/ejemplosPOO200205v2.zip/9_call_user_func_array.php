<?php

function funcion1(...$parametros){ // Número variable de parámetros
	echo 'función1: ';
	foreach ($parametros as $par) {
		echo $par . ', ';
	}
    echo '<br/>';
}

funcion1('par1', 'par2', 'par3');
funcion1(array('par1', 'par2', 'par3')); // Recibe un único parámetro
// y $parametros se compondrá de ese array como único elemento
// es decir, un array con solo el elemento array('par1', 'par2', 'par3')


function funcion2($par1, $par2, $par3){
    echo 'función2: ' . $par1 . ' ' . $par2 . ' ' . $par3 . ' <br/>';
}

function funcion3(array $par1){
    echo 'función3: ' . $par1[0] . ' ' . $par1[1] . ' ' . $par1[2] . ' <br/>';
}


$funciones = array('funcion1', 'funcion2');
foreach ($funciones as $funcion) {
	call_user_func_array($funcion, array('par1', 'par2', 'par3'));
}

call_user_func('funcion3', array('par1', 'par2', 'par3'));



echo "<br/><br/>***************************
				****** Ahora con POO ******
				***************************<br/><br/>";


class Clase {
    function metodo(...$parametros){
        echo 'método: ' . implode(', ',$parametros) . '<br/>';
    }
}


call_user_func_array('Clase::metodo',array('par1', 'par2', 'par3'));
call_user_func_array(array('Clase','metodo'), array('par1', 'par2', 'par3', 'par4'));

$obj = new Clase;
call_user_func_array(array($obj,'metodo'), array('par1', 'par2', 'par3', 'par4'));