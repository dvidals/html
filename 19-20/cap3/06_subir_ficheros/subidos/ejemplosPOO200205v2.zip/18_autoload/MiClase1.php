<?php

class MiClase1{
    function __construct() {
        echo 'Objeto creado de la clase ' . __CLASS__;
        
    }
}