<?php

class clase1 {
    private function dame_a() {
        echo 'a<br/>';
    }

    protected function dame_a_pro() {
        $this->dame_a();
    }
}

class clase2 extends clase1 {
    function dame_b() {
        echo 'b<br/>';
    }

    function dame_a() {
        parent::dame_a_pro();
    }
}

$o = new clase2();
$o->dame_a();